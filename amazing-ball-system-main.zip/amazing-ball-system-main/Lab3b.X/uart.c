/****************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Description: lab3 UART2 init,TX,RX functions   */
/*                                                  */
/****************************************************/

#include "uart.h"

inline void uart2_init(uint16_t baud)
{
	/* Implement me please. */
}

void uart2_send_8(int8_t data)
{
	/* Implement me please. */
}

int8_t uart2_recv(uint8_t* data)
{
	/* Implement me please. */
}
