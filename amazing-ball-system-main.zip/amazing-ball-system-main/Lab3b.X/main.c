//do not change the order of the following 3 definitions
#define FCY 12800000UL 
#include <stdio.h>
#include <libpic30.h>

#include <p33Fxxxx.h>
#include "types.h"
#include "uart.h"
#include "crc16.h"
#include "lab3.h"
#include "lcd.h"
#include "timer.h"

// Primary (XT, HS, EC) Oscillator without PLL
_FOSCSEL(FNOSC_PRIPLL);
// OSC2 Pin Function: OSC2 is Clock Output - Primary Oscillator Mode: XT Crystanl
_FOSC(OSCIOFNC_ON & POSCMD_XT);
// Watchdog Timer Enabled/disabled by user software
_FWDT(FWDTEN_OFF);
// Disable Code Protection
_FGS(GCP_OFF);   

volatile uint8_t timeout_flag = 0; // flag set to true if there is a timeout error in the TMR1 interrupt handler

void __attribute__ ((__interrupt__)) _T1Interrupt(void) {
    timeout_flag = 1; // set the timeout flag when the timer goes off
    stop_timer1();
    IFS0bits.T1IF = 0; // clear the interrupt flag
}

void start_timer1() {
    timeout_flag = 0;
    SETBIT(T1CONbits.TON); // Start Timer
}

void stop_timer1() {
    CLEARBIT(T1CONbits.TON); // Disable Timer
}

int main(void)
{	
    lcd_initialize();
    lcd_clear();
    uart2_init(9600); // init uart serial connection
    set_timer1(32767); // setup timer 1 to interrupt every 1 second
    
    uint16_t crc, crc_received;
            
    uint8_t start_byte;
    uint8_t crc_high = 0, crc_low = 0;
    uint8_t msg_len;
    uint8_t buf[MSG_MAX_LEN];
    
    uint16_t failed_sends = 0;
    uint8_t i;
    
    while (1) {
        // wait to receive the start byte from the server
        while (1) if (uart2_recv(&start_byte) == 0) break;
        start_timer1(); // start timer when first byte received

        
//        if (start_byte == MSG_START) {
//            start_timer1(); // start timer when first byte received
//        } else {
//            // data is corrupt - first byte is not 0x00
//            uart2_send_8(MSG_NACK); // Send NACK
//            failed_sends++;
//            continue;
//        }
        
        // Receive 16-bit CRC (2 bytes)    
        while (!timeout_flag) {
            if (uart2_recv(&crc_high) == 0) break;
        }

        while (!timeout_flag) {
            if (uart2_recv(&crc_low) == 0) break;
        }

        // wait to receive the length of the message
        while (!timeout_flag) {
            if (uart2_recv(&msg_len) == 0) break;
        }
        
        // receive the rest of the data message
        // read in the next n bytes and store them in the buffer
        uint8_t bytes_received = 0;
//        while (!timeout_flag && bytes_received < msg_len) {
//            while (!timeout_flag) {
//                if (uart2_recv(&buf[i] == 0)) {
//                    bytes_received++;
//                    break;
//                }
//            }
//        }
        for (i = 0; i < msg_len; i++) {
            // wait for the next byte of data, msg_len times
            while (!timeout_flag) {
                if (uart2_recv(&buf[i]) == 0) {
                    bytes_received++;
                    break;
                }
            }
        }
        
        stop_timer1(); // stop timer after all bytes are read   
        
        // handle data corruption
        if (start_byte != MSG_START || timeout_flag == 1 || bytes_received != msg_len) {
            uart2_send_8(MSG_NACK);
            timeout_flag = 0;
            failed_sends++;
            continue;
        }    
        
        // process the received CRC
        crc_received = crc_high;
        crc_received <<= 8;
        crc_received |= crc_low;
        
        // calculate the crc AFTER receiving all of the data
        crc = 0;
        for (i = 0; i < msg_len; i++) crc = crc_update(crc, buf[i]);

        // compare CRC and send ACK/NACK accordingly
        if (crc == crc_received) {
            uart2_send_8(MSG_ACK); // Send ACK
            
            // process the bytes in the buffer into a string
            char message[msg_len + 1]; // +1 to null terminate the string
            for (i = 0; i < msg_len; i++) message[i] = (char)buf[i];
            message[msg_len] = '\0';
            
            // after sending response to server, print data to the lcd screen
            lcd_clear(); // clear the lcd
            lcd_locate(0,0);
            lcd_printf_d("Recv fail: %u times", failed_sends);
            
            lcd_locate(0,1);
            lcd_printf_d("CRC: %X", crc);
            
            lcd_locate(0,2);
            lcd_printf_d("%s", message);
            
            failed_sends = 0; // msg successfully processed so reset counter for next msg
        } else {
            // handle data corruption
            uart2_send_8(MSG_NACK); // Send NACK
            failed_sends++;
            timeout_flag = 0;
        }
    }
    
    return 0;
}	

