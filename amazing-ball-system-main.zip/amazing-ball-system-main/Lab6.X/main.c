/***************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Lab5: Joystick ADC, PWM, Servo Motors & Touch   */
/*   (Ball Position Sampling)                       */
/*                                                  */
/***************************************************/

#include <p33Fxxxx.h>
#include <xc.h>
#define FCY 12800000UL
#include <stdio.h>
#include <libpic30.h>

#include "lcd.h"
#include "led.h"
#include "motor.h"    // Provides motor_init() and motor_set_duty()
#include "touch.h"    // Provides touch_init(), touch_select_dim(), and touch_read()

/* Initial configuration by EE */
// Primary (XT, HS, EC) Oscillator with PLL
_FOSCSEL(FNOSC_PRIPLL);

// OSC2 Pin Function: OSC2 is Clock Output - Primary Oscillator Mode: XT Crystal
_FOSC(OSCIOFNC_OFF & POSCMD_XT);

// Watchdog Timer Enabled/disabled by user software
_FWDT(FWDTEN_OFF);

// Disable Code Protection
_FGS(GCP_OFF);

#define PWM_PERIOD 4000
#define MIN_SERVO_VAL 0.9
#define MAX_SERVO_VAL 2.1
#define NUM_SAMPLES 5

uint16_t min_pwm = 0;
uint16_t max_pwm = 0;

uint16_t calculate_pwm(uint16_t pulse_width_ms){  
    float adjusted_val = 20 - pulse_width_ms;
    return (uint16_t) (adjusted_val * 200); // return it in terms of Period value
}

//set the two servo motors to specific PWM duty cycle values based on the desired corner position for the ball
void set_servo_corner(uint8_t corner) {
    switch (corner) {
        //both motors get min_pwm (placing the ball into one corner)
        case 1:
            motor_set_duty(7, min_pwm);
            motor_set_duty(8, min_pwm);
            break;
        //Y motor at max_pwm and X at min_pwm
        case 2:
            motor_set_duty(7, max_pwm);
            motor_set_duty(8, min_pwm);
            break;
        case 3:
            motor_set_duty(7, max_pwm);
            motor_set_duty(8, max_pwm);
            break;
        case 4:
            motor_set_duty(7, min_pwm);
            motor_set_duty(8, max_pwm);
            break;
        default:
            return;
    }
    //delay of 2 seconds for the ball to settle in the new corner
    __delay_ms(2000);
}

//collect ADC samples from the touchscreen for the specified dimension
void sample_touchscreen(uint16_t samples[5], uint16_t dim) {
    // enable the selected dimension
    touch_select_dim(dim);

    // sample 5 times
    uint8_t i;
    for (i = 0; i < NUM_SAMPLES; i++) {
        samples[i] = touch_read(); //called to sample the ADC values from the touchscreen
        __delay_ms(10);
    }
}

//sort an array of 5 ADC samples to extract the median value
//array sorted in ascending order
uint16_t calculate_median(uint16_t samples[5]) {
    // Simple bubble sort
    uint8_t i, j;
    for (i = 0; i < 4; i++) {
        for (j = i + 1; j < 5; j++) {
            if (samples[j] < samples[i]) {
                uint16_t temp = samples[i];
                samples[i] = samples[j];
                samples[j] = temp;
            }
        }
    }

    return samples[2]; // return third element (middle value = median)
}

//display the median X and Y values on the LCD
void display_median(uint8_t corner, uint16_t x_median, uint16_t y_median) {
    lcd_locate(0, corner);
    lcd_printf_d("C%d: X=%u, Y=%u", corner, x_median, y_median);
}

int main(void)
{
    // calculate the min and max pwms
    //converts the servo pwm to PWM duty values
    min_pwm = calculate_pwm(MIN_SERVO_VAL);
    max_pwm = calculate_pwm(MAX_SERVO_VAL);

    // Initialize peripherals
    __C30_UART=1;
    lcd_initialize();
    lcd_clear();
    motor_init(7);    // Initialize motor channel 7 (Y servo, e.g., OC7)
    motor_init(8);    // Initialize motor channel 8 (X servo, e.g., OC8)
    touch_init();     // Initialize touchscreen interface and ADC pins

    uint8_t corner = 1;
    uint16_t x_samples[5], y_samples[5];
    uint16_t x_median, y_median;

    while (1) {
        set_servo_corner(corner); //moves ball to the specified corner

        sample_touchscreen(x_samples, TOUCH_DIM_X); // sample x
        sample_touchscreen(y_samples, TOUCH_DIM_Y); // sample y

        //median calculations
        x_median = calculate_median(x_samples);
        y_median = calculate_median(y_samples);

        display_median(corner, x_median, y_median);

        //update corner
        corner = (corner + 1 > 4) ? 1 : corner + 1; //cycles through the 4 corners continuously
    }

    return 0;
}
