#####################################################
###                                               ###
### BU CAS CS454/654 Embedded Systems Development ###
###                                               ###
### Author: Renato Mancuso (BU)                   ###
###                                               ###
### File: FFT Generation/plotting demo            ###
###                                               ###
#####################################################

from scipy.fftpack import fft, fftshift, fftfreq
import numpy as np
import matplotlib.pyplot as plt

## Where to save generated figures
##savepath="/home/renato/BU/Classes/CS454_Sp24/Demos/Python/";

## Generic function to compute the FFT.
## @s: sampled signal for which to compute the FFT
## @fc: frequency of sampling in Hz
## returns: xf and yf ready for plotting

def getFFT(s, fc):
    # Sampling period
    Tc = 1/fc
    # Number of samples
    N = len(s)

    # Compute y-axis values 
    yf = fftshift(fft(s)/(N/2))

    # Shift and normalize x-axis values
    xf = fftshift(fftfreq(N, Tc))

    return xf, yf


def plotSignal(x, y, title):
    plt.title(title)
    plt.xlabel("time (s)")
    plt.ylabel("$s(t)$ value")
    plt.plot(x, y)
    plt.grid()
    plt.show()
    

def plotFFT(xf, yf, extra_label=""):
    plt.title("Fast Fuorier Transform (FFT) " + extra_label)
    plt.xlabel("frenqeucy (Hz)")
    plt.ylabel("magnitude of harmonic")
    plt.plot(xf, np.abs(yf))
    plt.xlim(-10, 10) #so that we can see the individual spikes of the graph
    plt.grid()
    plt.show()

### PART 3: Lab Assignment - 1 Hz Square Wave and FFT ###
#define parameters for the lab assignment
fs = 10000.0 #sampling rate in Hz
duration = 10.0 #in seconds
f_sq = 1.0 #frequency of the square wave in Hz
amp = 5

#create time axis
t = np.arange(0, duration, 1/fs) # create range from 0 to duration with step size of seconds per sample

#generate the square wave with amplitude between 0 and 5
square_wave = amp * (np.sign(np.sin(2 * np.pi * f_sq * t)) > 0) # convert smooth oscillation from sin to square wave with np.sign 
                                                              # converts the wave into binary values based on the condition (either high or low)

plotSignal(t, square_wave, "1 Hz Square Wave (0 to 5 amplitude)")

#compute FFT of the square wave and plot
xf, yf = getFFT(square_wave, fs)
plotFFT(xf, yf, "of 1 Hz Square Wave")
