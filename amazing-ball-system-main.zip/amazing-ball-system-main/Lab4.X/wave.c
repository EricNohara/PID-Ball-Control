/****************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Description: template file for digital and     */
/*                analog square wave generation     */
/*                via the LabJack U3-LV USB DAQ     */
/*                                                  */
/****************************************************/

#include "u3.h"
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define NANO 1e9

// Global variables for signal handling
double minVolt, maxVolt;
double inputFreq;
HANDLE hDevice;
int digitalState = 0; // Tracks digital output state
double analogState = 0; // Tracks analog output state
u3CalibrationInfo caliInfo;

/* This function should initialize the DAQ and return a device
 * handle. The function takes as a parameter the calibratrion info to
 * be filled up with what obtained from the device. */
HANDLE init_DAQ(u3CalibrationInfo * caliInfo)
{
	HANDLE handle;
	int localID = -1;
	
	/* Invoke openUSBConnection function here */
	handle = openUSBConnection(localID);
	
	/* Invoke getCalibrationInfo function here */
	if (getCalibrationInfo(handle, caliInfo) < 0) {
        fprintf(stderr, "Failed to get calibration info\n");
        exit(EXIT_FAILURE);
    }
	
	return handle;
}

double get_max_frequency() {
    struct timespec res;
    clock_getres(CLOCK_REALTIME, &res);
    return 1.0 / (res.tv_sec + res.tv_nsec / 1e9);
}

// Signal handler for digital output (FIO2) 
void signal_handler_digital(int signo)
{
    digitalState = !digitalState; // Toggle state
    // write digital state (high/low) to FIO2 digital output
    eDO(hDevice, 0, 2, digitalState); // Set FIO2 to digitalState
    // long eDO( HANDLE Handle, long ConfigIO, long Channel, long State);
}

// Signal handler for analog output (DAC0) 
void signal_handler_analog(int signo)
{
    analogState = (analogState == minVolt) ? maxVolt : minVolt;
    // write analog state to analog output DAC0
    eDAC(hDevice, (u3CalibrationInfo *) &caliInfo, 1, 0, analogState, 0, 0, 0);
    // long eDAC( HANDLE, u3CalibrationInfo, ConfigIO, Channel, Voltage, Binary, Reserved1, Reserved2);
}

void setup_timer(int signal, timer_t *timerId, double interval_sec)
{
    struct sigevent sev;
    struct itimerspec its;

    sev.sigev_notify = SIGEV_SIGNAL; // send the specified signal when the time goes off
    sev.sigev_signo = signal; // set the signal number to the specified signal
    sev.sigev_value.sival_ptr = timerId; // Store timer ID

    // setup signal handler based on the signal number
    sigaction(signal, &(struct sigaction){ .sa_handler = (signal == SIGRTMIN) ? signal_handler_digital : signal_handler_analog }, NULL);
    
    timer_create(CLOCK_REALTIME, &sev, timerId);
    
    its.it_interval.tv_sec = (time_t) interval_sec;
    its.it_interval.tv_nsec = (long) ((interval_sec - its.it_interval.tv_sec) * NANO);
    its.it_value = its.it_interval;

    timer_settime(*timerId, 0, &its, NULL);
}

int main(int argc, char **argv)
{
	/* Invoke init_DAQ and handle errors if needed */
	hDevice = init_DAQ(&caliInfo);
	if (hDevice == NULL) {
		fprintf(stderr, "Failed to initialize DAQ.\n");
        return EXIT_FAILURE;
	}

	/* Provide prompt to the user for a voltage range between 0
	 * and 5 V. Require a new set of inputs if an invalid range
	 * has been entered. */
    int first = 1;
	do {
        if (!first) printf("Error: invalid input. Voltages must be between 0 and 5!\n");
        first = 0;
        printf("Enter min voltage (0-5V): ");
        scanf("%lf", &minVolt);
        printf("Enter max voltage (0-5V): ");
        scanf("%lf", &maxVolt);
    } while (minVolt < 0 || maxVolt > 5 || minVolt >= maxVolt);
	
	/* Compute the maximum resolutiuon of the CLOCK_REALTIME
	 * system clock and output the theoretical maximum frequency
	 * for a square wave */
    double maxFreq = get_max_frequency();
    printf("Max Frequency with CLOCK_REALTIME System Clock: %lf\n", maxFreq);
	
	/* Provide prompt to the user to input a desired square wave
	 * frequency in Hz. */
	do {
        printf("Enter square wave frequency (Hz, max %.2f): ", maxFreq);
        scanf("%lf", &inputFreq);
    } while (inputFreq <= 0 || inputFreq > maxFreq);
    
    // variables to store decision on wave type 
     char analogInput, digitalInput;
     int validSelection = 0; 
    
     // loop until we get an input 
     do {
         printf("Do you want an analog wave? (Y/N)");
         scanf(" %c", &analogInput); 
         analogInput = toupper(analogInput); // toupper makes it where it allows both lower/upper case letters (makes it uppercase)
        
         printf("Do you want an Digital wave? (Y/N)");
         scanf(" %c", &digitalInput);
         digitalInput = toupper(digitalInput); // toupper makes it where it allows both lower/upper case letters (makes it uppercase)
    
         if ((analogInput =='Y' && digitalInput == 'N') || (analogInput == 'N' && digitalInput =='Y')){
             validSelection = 1;
         } else {
             printf("Error: please select something that is correct (look at demo :) )");
         }
     } while (!validSelection);
        

	/* Program a timer to deliver a SIGRTMIN signal, and the
	 * corresponding signal handler to output a square wave on
	 * BOTH digital output pin FIO2 and analog pin DAC0. */

	/* The square wave generated on the DAC0 analog pin should
	 * have the voltage range specified by the user in the step
	 * above. */
	timer_t digitalTimer, analogTimer;
     int digitalTimerSet = 0, analogTimerSet = 0;
     if (digitalInput == 'Y'){
        // since timer needs to fire once for high to low and once for low to high per period
         setup_timer(SIGRTMIN, &digitalTimer, 1.0 / (2 * inputFreq)); 
         digitalTimerSet = 1;
     }
	 if (analogInput == 'Y'){
        // since timer needs to fire once for high to low and once for low to high per period
         setup_timer(SIGRTMAX, &analogTimer, 1.0 / (2 * inputFreq)); 
         analogTimerSet = 1;
     }

	/* Display a prompt to the user such that if the "exit"
	 * command is typed, the USB DAQ is released and the program
	 * is terminated. */
	char input[10];
    printf("Type 'exit' to quit: ");
	while (1) {
		scanf("%s", input);
		if (strcmp(input, "exit") == 0) break;
	}
    
    // clean up code
     if(analogTimerSet){
         timer_delete(analogTimer);
     }
     if(digitalTimerSet){
         timer_delete(digitalTimer);
     }

    closeUSBConnection(hDevice);
    
    printf("Program terminated. USB device released\n");
	
	return EXIT_SUCCESS;
}
