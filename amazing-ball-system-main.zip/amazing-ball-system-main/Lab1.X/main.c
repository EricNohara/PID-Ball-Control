/****************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Description: simple HelloWorld application     */
/*                for Amazing Ball platform         */
/*                                                  */
/****************************************************/

#include <p33Fxxxx.h>
#include <xc.h> //for __delay_ms() and __delay_us() (built in delay functions)
//do not change the order of the following 3 definitions
#define FCY 12800000UL 
#include <stdio.h>
#include <libpic30.h>
#include <uart.h>

#include "lcd.h"
#include "joystick.h"
#include "led.h"

#define DEBOUNCE_THRESHOLD 10 // just a random threshold for determining if button is pressed - need to find the optimal one
#define PRESSED_STATE 1 // constant values passed into IS_BUTTON macro to determine the action type
#define RELEASED_STATE 0

/* Initial configuration by EE */
// Primary (XT, HS, EC) Oscillator with PLL
_FOSCSEL(FNOSC_PRIPLL);

// OSC2 Pin Function: OSC2 is Clock Output - Primary Oscillator Mode: XT Crystal
_FOSC(OSCIOFNC_OFF & POSCMD_XT); 

// Watchdog Timer Enabled/disabled by user software
_FWDT(FWDTEN_OFF);

// Disable Code Protection
_FGS(GCP_OFF);  

//counts the number of debounced button 1 events
uint8_t btn1_count = 0;


// polling implementation of debouncing, which also has baked in logic to increment the count if there is a state change after button 1 is pressed
// if the input signal does not persist for the DEBOUNCE_THRESHOLD, return false, else return true
// continually sample the input from the inputted button
//pass address of btn1_count in main() into count so that the function can increment it when a valid button pressed is detected
static inline uint8_t debounce_btn1(uint8_t input_state, uint8_t *current_state, uint8_t *count) {
    uint8_t result = 1, i;
	//loop for DEBOUNCE_THRESHOLD times and if hardware reading does not match desired state set result to 0 and update current state as needed
    for (i = 0; i < DEBOUNCE_THRESHOLD; i++) {
        if (input_state == PRESSED_STATE && !BTN1_PRESSED()) {
            result = 0;
            *current_state = RELEASED_STATE;
            break;
        } else if (input_state == RELEASED_STATE && !BTN1_RELEASED()) {
            result = 0;
            *current_state = PRESSED_STATE;
            break;
        }
    }

	//if result remains 1, check if there has been any change and if so increment count only if global btn1_count is 0
    if (result) {
        if (*current_state != input_state && btn1_count == 0) (*count)++; 
        *current_state = input_state;
    }
    
    return result;
}

static inline uint8_t debounce_btn2(uint8_t state) {
    uint8_t i;
    for (i = 0; i < DEBOUNCE_THRESHOLD; i++) {
        if ((state == 1 && !BTN2_PRESSED()) || (state == 0 && !BTN2_RELEASED())) return 0;
    }
    return 1;
}

int main(){
	/* LCD Initialization Sequence */
	__C30_UART=1;	
	lcd_initialize();
	lcd_clear();
    
    /*display team members*/
	lcd_locate(0,0);
	lcd_printf("Ale");
    lcd_locate(0,1);
	lcd_printf("Matias");
    lcd_locate(0,2);
	lcd_printf("Eric");
    lcd_locate(0,3);
	lcd_printf("Alex");
    
    /*LED4 blink x3 (1s interval)*/
    CLEARLED(LED4_TRIS); //set LED4 as output
    
    uint8_t i; // declaring i to use in for loop - use one byte only because dont need more than 255
    
    /*blink LED4 3 times with 1 second on/off cycle*/
    for  (i=0; i<3; i++){
      SETLED(LED4_PORT); //turn LED4 on
      __delay_ms(1000); //wait one sec
      CLEARLED(LED4_PORT); //turn LED4 off
      __delay_ms(1000); //wait another sec
    }
    CLEARLED(LED4_PORT); //at the end of three blinks LED4 remains off

    /*configuration of LED1, LED2, LED3 as digital output and button pins as inputs*/
    CLEARLED(LED1_TRIS);
    CLEARLED(LED2_TRIS);
    CLEARLED(LED3_TRIS);
    
    /*joystick button counter*/
    uint8_t btn1_count = 0;
    lcd_locate(0,4);
    lcd_printf("COUNTER: 0x00 000");
    uint8_t oldBtn1State = 0; //0 means not pressed initially
    
    // configure the joystick buttons to be set to input
    CONFIGURE_BTN1();
    CONFIGURE_BTN2();
    
    // keep the current state for button 1 so we can keep track if the count should be incremented
    uint8_t btn1_state = RELEASED_STATE;
    uint8_t prev_state = btn1_state; //used to determine if the count was incremented
    
	while(1){
		/*check joystick button presses*/
	  //LED1 on when button1 pressed
        if (debounce_btn1(PRESSED_STATE, &btn1_state, &btn1_count)){
            SETLED(LED1_PORT);
          }else{
            CLEARLED(LED1_PORT);
          }

	  //LED2 ON when button2 pressed
	  //off when not pressed
	  if (debounce_btn2(PRESSED_STATE)){
	    SETLED(LED2_PORT);
	  }else{
	    CLEARLED(LED2_PORT);
	  }

	  //LED3 on if BTN1 != BTN2 (XOR)
	  //LED3 off if BTN1 == BTN2
        
        if ((debounce_btn1(PRESSED_STATE, &btn1_state, &btn1_count) && debounce_btn2(RELEASED_STATE)) || 
                (debounce_btn1(RELEASED_STATE, &btn1_state, &btn1_count) && debounce_btn2(PRESSED_STATE))) {
            SETLED(LED3_PORT);
        } else {
            CLEARLED(LED3_PORT);
        }
        
        // only update if there was a change in count 
        if (prev_state != btn1_state) {
            prev_state = !btn1_state;
            lcd_locate(0, 4);
            lcd_printf("COUNTER: 0x%02X %03d", btn1_count, btn1_count);
        }

	  __delay_ms(10); //wait 10ms before the next loop iteration
	}
	
	return 0;
}


