#include "touch.h"
#include <p33Fxxxx.h>
#include <xc.h>
#include <libpic30.h>

/**
 * @brief Initialize the touchscreen ADC and associated pins.
 *
 * This function configures ADC1 for 10-bit operation with auto-conversion.
 * It sets AN15 (X-dimension) and AN9 (Y-dimension) as analog inputs.
 */
void touch_init(void) {
    // Disable ADC before configuring
    AD1CON1bits.ADON = 0;

    // Set ADC for 10-bit operation and integer output
    AD1CON1bits.AD12B = 0;    // 10-bit mode
    AD1CON1bits.FORM = 0;     // Integer output
    AD1CON1bits.SSRC = 0x7;   // Auto conversion trigger
    AD1CON2 = 0;              // Disable scanning (single channel mode)

    // Set ADC timing: sample time and conversion clock.
    AD1CON3bits.ADRC = 0;     // Use internal clock
    AD1CON3bits.SAMC = 0x1F;  // Auto-sample time bits (adjust if needed)
    AD1CON3bits.ADCS = 2;     // Tad = 3 * Tcy

    // Configure AN15 and AN9 as analog inputs:
    // For dsPIC33F, AN0-15 are configured via AD1PCFGL.
    AD1PCFGLbits.PCFG15 = 0;  // Set AN15 to analog (for X)
    AD1PCFGLbits.PCFG9  = 0;  // Set AN9 to analog (for Y)

    // (If your hardware requires further TRIS or LAT configuration for touchscreen control pins,
    //  add that here.)

    // Enable ADC
    AD1CON1bits.ADON = 1;
}

/**
 * @brief Select the touchscreen dimension to sample.
 *
 * Sets the ADC channel for sampling based on the selected dimension.
 *
 * @param dimension TOUCH_DIM_X for X-dimension (AN15) or TOUCH_DIM_Y for Y-dimension (AN9).
 */
void touch_select_dim(uint8_t dimension) {
    if (dimension == TOUCH_DIM_X) {
        AD1CHS0bits.CH0SA = 15;  // Select AN15 for X-dimension
    } else if (dimension == TOUCH_DIM_Y) {
        AD1CHS0bits.CH0SA = 9;   // Select AN9 for Y-dimension
    }
}

/**
 * @brief Read a sample from the touchscreen.
 *
 * Assumes that touch_select_dim() has been called to select the desired dimension.
 *
 * @return uint16_t ADC sample result from the touchscreen.
 */
uint16_t touch_read(void) {
    // Start sampling
    AD1CON1bits.SAMP = 1;
    // Wait until conversion is complete
    while (!AD1CON1bits.DONE);
    AD1CON1bits.DONE = 0;  // Clear the DONE flag
    return ADC1BUF0;       // Return the ADC conversion result
}
