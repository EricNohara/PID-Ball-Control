/***************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Lab5: Joystick ADC, PWM, Servo Motors & Touch   */
/*   (Ball Position Sampling)                       */
/*                                                  */
/***************************************************/

#include <p33Fxxxx.h>
#include <xc.h>
#define FCY 12800000UL
#include <stdio.h>
#include <libpic30.h>

#include "lcd.h"
#include "led.h"
#include "joystick.h" // Provides BTN1_PRESSED() macro and joystick_get_x()/joystick_get_y() prototypes
#include "motor.h"    // Provides motor_init() and motor_set_duty()
#include "touch.h"    // Provides touch_init(), touch_select_dim(), and touch_read()

/* Initial configuration by EE */
// Primary (XT, HS, EC) Oscillator with PLL
_FOSCSEL(FNOSC_PRIPLL);

// OSC2 Pin Function: OSC2 is Clock Output - Primary Oscillator Mode: XT Crystal
_FOSC(OSCIOFNC_OFF & POSCMD_XT); 

// Watchdog Timer Enabled/disabled by user software
_FWDT(FWDTEN_OFF);

// Disable Code Protection
_FGS(GCP_OFF);  

//define PWM_PERIOD (4000 counts for a 20ms period)
#define PWM_PERIOD 4000

// Debounce threshold: number of consecutive samples required.
#define DEBOUNCE_THRESHOLD 100

#define MIN_SERVO_VAL 0.9

#define MAX_SERVO_VAL 2.1

/**
 * @brief Simple debounce function.
 *
 * Calls the provided read_input function DEBOUNCE_THRESHOLD times
 * and returns 1 only if all samples equal the expected value.
 *
 * @param read_input A function that returns the current digital state.
 * @param expected   The value we require for a stable reading (1 for pressed).
 * @return 1 if stable, 0 otherwise.
 */
uint8_t debounce(uint8_t (*read_input)(void), uint8_t expected)
{
    uint8_t i = 0;
    while (i < DEBOUNCE_THRESHOLD)
    {
        if (read_input() != expected)
        {
            return 0;
        }
        i++;
    }
    return 1;
}


/**
 * @brief Helper function to read BTN1 state.
 *
 * BTN1 is connected to PORTEbits.RE8 and uses active-low logic.
 *
 * @return 1 if BTN1 is pressed, 0 otherwise.
 */
uint8_t read_BTN1(void)
{
    return BTN1_PRESSED() ? 1 : 0;
}

//calculates the new PWM compare value based on the joystick readings 
//computes the midpoint of the calibrated range and gets the normalized deviation, maps it to a pulse width (in ms)
//center = 1.5ms, maximum deviation gives 0.9ms (when ratio +1) and 2.1ms (when ratio -1)
//converts the pulse width to counts (each count is 5us) and then subtracts that count value from PWM_PERIOD
uint16_t calculate_pwm(uint16_t joystick_val, uint16_t min_val, uint16_t max_val){
    float range = max_val - min_val;
    float normalized_val = joystick_val / range;
    float range_servo = MAX_SERVO_VAL - MIN_SERVO_VAL;
    
    //map the ratio to a pulse width in ms
    float width_ms = range_servo * normalized_val + MIN_SERVO_VAL;
    float adjusted_val = 20 - width_ms;
    return (uint16_t) (adjusted_val * 200); // return it in micro seconds
    
    //when ratio = 0, pulse = 1.5ms; when ratio = +1, pulse = 0.9ms; when ratio = -1, pulse = 2.1ms
//    float pulse_ms = 1.5 - ratio;
//    float pulse_us = pulse_ms * 1000.0; //convert ms to microseconds
//    uint16_t pulse_counts = pulse_us / 5; //convert microseconds to timer counts
//    return PWM_PERIOD - pulse_counts;
}

/**
 * @brief Maps a joystick ADC value (from a calibrated range) to a servo pulse width.
 *
 * For the servo, a pulse width of 900us corresponds to 0° and 2100us to 180°.
 *
 * @param val      The current ADC value.
 * @param min_val  The calibrated minimum value.
 * @param max_val  The calibrated maximum value.
 * @return uint16_t The corresponding pulse width in microseconds.
 */
uint16_t map_value(uint16_t val, uint16_t min_val, uint16_t max_val)
{
    if (max_val <= min_val)
        return 1500;
    return 900 + ((uint32_t)(val - min_val) * (2100 - 900)) / (max_val - min_val);
}

int main(void)
{
    uint16_t max_x, min_x, max_y, min_y;
    int current_val;
    uint16_t final_pwm_x, final_pwm_y;

    // Initialize peripherals
    __C30_UART=1;	
    lcd_initialize();
    joystick_adc_init();
    lcd_clear();
    motor_init(7);    // Initialize motor channel 7 (Y servo, e.g., OC7)
    motor_init(8);    // Initialize motor channel 8 (X servo, e.g., OC8)
    touch_init();     // Initialize touchscreen interface and ADC pins
    CONFIGURE_BTN1(); // Configure BTN1 (fire button) for joystick
    current_val = 0;

    // --- Joystick Calibration ---
    // Calibrate Maximum X Position
    while (!debounce(read_BTN1, 1))
    {
        max_x = joystick_get_x();
        lcd_locate(0, 1);
        lcd_printf_d("TS max X? = %d  \r", max_x);
    }
    
    while(!debounce(read_BTN1, 0));

    // Calibrate Minimum X Position
    while (!debounce(read_BTN1, 1))
    {
        min_x = joystick_get_x();
        lcd_locate(0, 2);
        lcd_printf_d("TS min X? = %d  \r", min_x);
    }
    
    while(!debounce(read_BTN1, 0));

    // Calibrate Maximum Y Position
    while (!debounce(read_BTN1, 1))
    {
        max_y = joystick_get_y();
        lcd_locate(0, 3);
        lcd_printf_d("TS max Y? = %d  \r", max_y);
    }
    
    while(!debounce(read_BTN1, 0));

    // Calibrate Minimum Y Position
    while (!debounce(read_BTN1, 1))
    {
        min_y = joystick_get_y();
        lcd_locate(0, 4);
        lcd_printf_d("TS min Y? = %d  \r", min_y);
    }
    
    while(!debounce(read_BTN1, 0));
    
    //debugging loop
//    while(1){
//        uint16_t raw_y = joystick_get_y();
//        uint16_t raw_x = joystick_get_x();
//        lcd_clear_row(6);
//        lcd_clear_row(7);
//        lcd_locate(0,6);
//        lcd_printf_d("Raw Y: %d\r", raw_y);
//        lcd_locate(0,7);
//        lcd_printf_d("Raw X: %d\r", raw_x);
//    }

    // --- Set Servo PWM Based on Joystick ---
    // For X-dimension servo
    while (!debounce(read_BTN1, 1))
    {
        current_val = joystick_get_x();
        uint16_t pwm_x = calculate_pwm(current_val, min_x, max_x);
        lcd_locate(0, 5);
        lcd_printf_d("PWM X: %d   \r", pwm_x);
        motor_set_duty(8, pwm_x); // Channel 8 drives X servo
    }
    
    final_pwm_x = calculate_pwm(joystick_get_x(), min_x, max_x);
    motor_set_duty(8, final_pwm_x); // set the motor to its final position
    
    while(!debounce(read_BTN1, 0));

    // For Y-dimension servo
    while (!debounce(read_BTN1, 1))
    {
        current_val = joystick_get_y();
        uint16_t pwm_y = calculate_pwm(current_val, min_y, max_y);
        lcd_locate(0, 6);
        lcd_printf_d("PWM Y: %d   \r", pwm_y);
        motor_set_duty(7, pwm_y); // Channel 7 drives Y servo
    }

    final_pwm_y = calculate_pwm(joystick_get_y(), min_y, max_y);
    motor_set_duty(7, final_pwm_y);

    while (!debounce(read_BTN1, 0));
    
     //for x and y dimension servo
    while (!debounce(read_BTN1, 1))
     {
         uint16_t current_x = joystick_get_x();
         uint16_t current_y = joystick_get_y();
         uint16_t pwm_x = calculate_pwm(current_x, min_x, max_x);
         uint16_t pwm_y = calculate_pwm(current_y, min_y, max_y);
        
         lcd_locate(0, 7);
         lcd_printf_d("PWM X: %d, Y: %d   \r", pwm_x, pwm_y);
        
         motor_set_duty(8, pwm_x); 
         motor_set_duty(7, pwm_y);
     }

     final_pwm_x = calculate_pwm(joystick_get_x(), min_x, max_x);
     final_pwm_y = calculate_pwm(joystick_get_y(), min_y, max_y);
     motor_set_duty(8, final_pwm_x);
     motor_set_duty(7, final_pwm_y);

    return 0;
}