/****************************************************/
/*                                                  */
/*   CS-454/654 Embedded Systems Development        */
/*   Instructor: Renato Mancuso <rmancuso@bu.edu>   */
/*   Boston University                              */
/*                                                  */
/*   Description: simple HelloWorld application     */
/*                for Amazing Ball platform         */
/*                                                  */
/****************************************************/

#include <p33Fxxxx.h>
#include <xc.h> //for __delay_ms() and __delay_us() (built in delay functions)
//do not change the order of the following 3 definitions
#define FCY 12800000UL 
#include <stdio.h>
#include <libpic30.h>
#include <uart.h>

#include "lcd.h"
#include "joystick.h"
#include "led.h"

/* Initial configuration by EE */
// Primary (XT, HS, EC) Oscillator with PLL
_FOSCSEL(FNOSC_PRIPLL);

// OSC2 Pin Function: OSC2 is Clock Output - Primary Oscillator Mode: XT Crystal
_FOSC(OSCIOFNC_OFF & POSCMD_XT); 

// Watchdog Timer Enabled/disabled by user software
_FWDT(FWDTEN_OFF);

// Disable Code Protection
_FGS(GCP_OFF);  

//global variable
uint32_t num_ms = 0;
uint32_t current_ms = 0;
uint32_t last_press_ms = 0;

#define DEBOUNCE_THRESHOLD 50
#define MS_PER_CLOCK_CYCLE 0.000078125 // got this by taking 1 / 12,800,000 Hz => seconds/cycle * 1/1000 ms/seconds to get ms/cycle

// macro for converting ms to "00:00.000" format and printing to LCD
//converts a ms value n into mins, secs, and ms
#define MS_TO_TIME_FORMAT(n) ({ \
    uint8_t min = ((n) % 3600000) / 60000; \
    uint8_t sec = ((n) % 60000) / 1000; \
    uint8_t ms = (n) % 1000; \
    lcd_locate(0,1); \
    lcd_printf("%02u:%02u.%03u", min, sec, ms); \
})

//calculate ms from number of cycles
//takes a cycle count from timer 3 and calculates how much time that count represents
//time_ms converts cycles to ms
#define PRINT_ITERATION_INFO(count) ({ \
    double time_ms = (count) * MS_PER_CLOCK_CYCLE; \
    lcd_locate(0,2); \
    lcd_printf("CYCLES: %u", count); \
    lcd_locate(0,3); \
    lcd_printf("TMR3: %.4fms", time_ms); \
})


// functions that handle setup for timers:
static inline void setup_timer1() {
    __builtin_write_OSCCONL(OSCCONL | 2);
    T1CONbits.TON = 0; //Disable Timer
    T1CONbits.TCS = 1; //Select external clock
    T1CONbits.TSYNC = 0; //Disable Synchronization
    T1CONbits.TCKPS = 0b00; //Select 1:1 Prescaler
    TMR1 = 0x00; //Clear timer register
    PR1 = 32767; //Load the period value
    IPC0bits.T1IP = 0x07; // Set Timer1 Interrupt Priority Level higher than TMR2 to ensure the interrupt happes ASAP
    IFS0bits.T1IF = 0; // Clear Timer1 Interrupt Flag
    IEC0bits.T1IE = 1;// Enable Timer1 interrupt
    T1CONbits.TON = 1;// Start Timer
}

static inline void setup_timer2() {
    CLEARBIT(T2CONbits.TON); // Disable Timer
    CLEARBIT(T2CONbits.TCS); // Select internal instruction cycle clock
    CLEARBIT(T2CONbits.TGATE); // Disable Gated Timer mode
    TMR2 = 0x00; // Clear timer register
    T2CONbits.TCKPS = 0b11; // Select 1:256 Prescaler
    PR2 = 50; // Load the period value = 1 / (1 / ((12.8 * 1000) / 256)) ==> got this through the conversion we did in class to trigger in interrupt every 1ms
    
    // enabling interrupts for our timer 2
    IPC1bits.T2IP = 0x01; // Set Timer2 Interrupt Priority Level to 1
    CLEARBIT(IFS0bits.T2IF); // Clear Timer2 Interrupt Flag
    SETBIT(IEC0bits.T2IE); // Enable Timer2 interrupt
    SETBIT(T2CONbits.TON); // Start Timer
}

static inline void setup_timer3() {
    CLEARBIT(T3CONbits.TON); // Disable Timer
    CLEARBIT(T3CONbits.TCS); // Select internal instruction cycle clock
    CLEARBIT(T3CONbits.TGATE); // Disable Gated Timer mode
    TMR3 = 0x00; // Clear timer register
    T3CONbits.TCKPS = 0b00; // Select 1:1 Prescaler
    SETBIT(T3CONbits.TON); // Start Timer
}

//configure external interrupt INT1 to trigger on falling edge
static inline void setup_INT1(void){
    INTCON2bits.INT1EP = 1; //falling edge trigger (active low button)
    IPC5bits.INT1IP = 0x01; // set INT1 priority
    IFS1bits.INT1IF = 0; //clear INT1 interrupt flag
    IEC1bits.INT1IE = 1; //enable INT1 interrupt
}

// Interrupt Service Routines for timers 1 and 2 triggered when Timers counter matches the timer period.
//every time timer 1 reaches its period (32767 counts) this ISR toggles LED2
void __attribute__((__interrupt__, no_auto_psv)) _T1Interrupt(void)
{
    TOGGLELED(LED2_PORT);
    IFS0bits.T1IF = 0; // clear the interrupt flag to avoid re-entering ISR immediately
}

//ISR triggered every 1ms (set by TMR2) and increments the global num_ms counter
//every time num_ms is a multiple of 5 it toggles LED1
void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void)
{
    if (++num_ms % 5 == 0) TOGGLELED(LED1_PORT); // toggle the LED every 5 ms + increment the ms count every ms
    current_ms++;
    IFS0bits.T2IF = 0; // clear the interrupt flag
}

//INT1 ISR- resets the timer count when the fire button is pressed
//when external button is pressed ISR resets both the ms counter (current_ms) and TMR3's counter (TMR3)
//restarts timing measurements
void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void)
{
    current_ms = (num_ms - last_press_ms > DEBOUNCE_THRESHOLD) ? 0 : current_ms; // debounce the button and reset the current ms
    last_press_ms = num_ms;
    IFS1bits.INT1IF = 0; // clear the interrupt flag so ISR isn't immediately called again
}

//busy-waiting (doing nothing more than toggling an LED and counting iterations)
//after 25,000 iterations it updates the LCD with timing information
int main(){
    // initializing the LCD
	__C30_UART=1;	
	lcd_initialize();
	lcd_clear();
    
    // configure the LEDs we will use as digital output
    CLEARLED(LED4_TRIS);
    CLEARLED(LED1_TRIS);
    CLEARLED(LED2_TRIS);
    
    // configure the button 1 as digital input
    CONFIGURE_BTN1();
    
    // configure the timers we are going to use - 1 and 2
    setup_timer1();
    setup_timer2();
    setup_timer3();
    
    //setup external interrupt for the fire button (INT1)
    setup_INT1(); //when button pressed it resets the timing counters
    
    uint16_t num_iterations = 0; //counts how many iterations of the main loop have occurred
    
    // main program loop
	while(1){
        TMR3 = 0; //rest timer 3 at the start of each iteration to measure the length of ONE SINGLE iteration
        TOGGLELED(LED4_PORT); //on every loop iteration LED4 is toggled (gives an idea of CPU speed)

        if (++num_iterations >= 25000) {
            MS_TO_TIME_FORMAT(current_ms); //converts the ms counter into mm:ss.mmm string
			num_iterations = 0; // reset the iterations so another 25000 iterations pass before we print again

			PRINT_ITERATION_INFO(TMR3); //calculate the elapsed time in ms from TMR3 cycle count and print raw cycle count
        }
	}
	
	return 0;
}


