from dataclasses import dataclass
import pybullet as p
import time
import numpy as np
import utils
import argparse
from scipy.signal import butter

@dataclass
class Point:
    x: float
    y: float

#global variable to remember previous error across calls 
last_error = Point(0.0, 0.0)

#filter parameters (butterworth low pass)
N_ord = 4 #filter order: number of poles/ zeros
f_cutoff = 6.0 #cutoff frequency (Hz)
fc = 100.0 #sampling frequency (Hz): controller runs at 100 Hz
wn = f_cutoff / (0.5 * fc) #normalized cutoff (Nyquist = fc/2)
#compute Butterworth filter coefficients (b: feedforward, a: feedback)
b, a = butter(N_ord, wn, btype='low', analog=False)
#initialize history buffers for input (xHistory, yHistory) and output (xFilterHistory, yFilterHistory)
xHistory = [0.0]*(N_ord + 1)
yHistory = [0.0]*(N_ord + 1)
xFilterHistory = [0.0]*(N_ord + 1)
yFilterHistory = [0.0]*(N_ord + 1)

@dataclass
class World:
    """A class to hold the world objects"""
    plate: int
    sphere: int

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--setpoint", type=float, nargs=2, default=(0.0,0.0))
    parser.add_argument("--kp", type=float, default=0.0) # set these values to tune the PD controller
    parser.add_argument("--kd", type=float, default=0.0) # set these values to tune the PD controller
    parser.add_argument("--noise", action="store_true", help="Add noise to the measurements")
    parser.add_argument("--filtered", action="store_true", help="filter the measurements")
    cmd_args = parser.parse_args()
    print(cmd_args) #echo settings
    #convert tuple to Point for convenience
    cmd_args.setpoint = Point(*cmd_args.setpoint)
    return cmd_args

def run_controller(kp, kd, setpoint, noise, filtered, world: World):

    def set_plate_angles(theta_x, theta_y):
        #limit plate rotation and send position control to joint motors
        p.setJointMotorControl2(world.plate, 1, p.POSITION_CONTROL, targetPosition=np.clip(theta_x, -0.1, 0.1), force=5, maxVelocity=2)
        p.setJointMotorControl2(world.plate, 0, p.POSITION_CONTROL, targetPosition=np.clip(-theta_y, -0.1, 0.1), force=5, maxVelocity=2)

    # you can set the variables that should stay accross control loop here
    #previous error for derviative calculation
    last_error_x = 0.0
    last_error_y = 0.0

    def pd_controller(x, y, kp, kd, setpoint):
        """Implement a PD controller, you can access the setpoint via setpoint.x and setpoint.y
        the plate is small around 0.1 to 0.2 meters. You will have to calculate the error and change in error and 
        use those to calculate the angle to apply to the plate."""
        nonlocal last_error_x, last_error_y # modify only in local scope

        dt = 0.01 #sampling period of 10ms

        # Current Error = setpoint - actual point
        #compute errors in each axis
        error_x = setpoint.x - x
        error_y = setpoint.y - y

        # Proportional
        p_error_x = kp * error_x
        p_error_y = kp * error_y

        # Derivative
        #calculate derivative of error (change in error over dt)
        d_error_x = kd * (error_x - last_error_x)/dt
        d_error_y = kd * (error_y - last_error_y)/dt

        #update last error for the next iteration
        last_error_x = error_x
        last_error_y = error_y

        # PD output
        #calculate control using proportional and derivative terms (to get plate angles)
        x_angle = p_error_x + d_error_x
        y_angle = p_error_y + d_error_y

        return x_angle, y_angle


    def filter_val(x, y):
        """Implement a filter here, you can use scipy.signal.butter to compute the filter coefficients and then scipy.signal.lfilter to apply the filter.but we recommend you implement it yourself instead of using lfilter because you'll have to do that on the real system later.
        Take a look at the butterworth example written by Renato for inspiration."""
        global xHistory, yHistory, xFilterHistory, yFilterHistory

        #shift input history: newest measurement at index 0
        xHistory = [x] + xHistory[:-1]
        yHistory = [y] + yHistory[:-1]
        #shift output history; prepare output history slot for new value
        xFilterHistory = [0.0] + xFilterHistory[:-1]
        yFilterHistory = [0.0] + yFilterHistory[:-1]

        #compute new output samples
        x_out = 0.0
        y_out = 0.0
        #b-terms (feed-forward)
        for i in range(len(b)):
            x_out += b[i] * xHistory[i]
            y_out += b[i] * yHistory[i]
        #a-terms (feedback) skipping a[0]
        #a[0] is normalized to 1.0 so we start at i = 1 and use xFilterHistory[i] (y[n-i])
        for i in range(1, len(a)):
            x_out -= a[i] * xFilterHistory[i]
            y_out -= a[i] * yFilterHistory[i]
        #store filtered outputs at index 0
        xFilterHistory[0] = x_out
        yFilterHistory[0] = y_out

        return x_out, y_out

    def every_10ms(i: int, t: float):
        '''This function is called every ms and performs the following:
        1. Get the measurement of the position of the ball
        2. Calculate the forces to be applied to the plate
        3. Apply the forces to the plate
        '''
        (x,y,z), orientation = p.getBasePositionAndOrientation(world.sphere)
        if noise:
            x += utils.noise(t) # the noise added has a frequency between 30 and 50 Hz
            y += utils.noise(t, seed = 43) # so that the noise on y is different than the one on x
        
        raw_x, raw_y = x, y

        #filter measurement
        if filtered:
            x, y = filter_val(x, y)

        #compute control action
        (angle_x, angle_y) = pd_controller(x, y, kp, kd, setpoint)
        set_plate_angles(angle_x, angle_y)

        if i%100 == 0: # print every 100 ms
            #print(f"t: {t:.2f}, x: {x:.3f},\ty: {y:.3f},\tax: {angle_x:.3f},\tay: {angle_y:.3f}")
            print(f"t: {t:.2f} | "f"raw=({raw_x:.3f},{raw_y:.3f}) ➔ "f"filt=({x:.3f},{y:.3f}) | "f"ax={angle_x:.3f}, ay={angle_y:.3f}")
    utils.loop_every(0.01, every_10ms) # we run our controller at 100 Hz using a linux alarm signal

def run_simulation( initial_ball_position = Point(np.random.uniform(-0.2, 0.2),
                                                  np.random.uniform(-0.2, 0.2))):
    p.connect(p.GUI)
    p.setAdditionalSearchPath("assets")
    plate = p.loadURDF("plate.urdf")
    sphere = p.createMultiBody(0.2
        , p.createCollisionShape(p.GEOM_SPHERE, radius=0.04)
        , basePosition = [initial_ball_position.x,initial_ball_position.y,0.5]
    )

    #zoom to the plate
    p.resetDebugVisualizerCamera(cameraDistance=1.0, cameraYaw=0, cameraPitch=-45, cameraTargetPosition=[0,0,0])

    p.setJointMotorControl2(plate, 0, p.POSITION_CONTROL, targetPosition=0, force=5, maxVelocity=2)
    p.setJointMotorControl2(plate, 1, p.POSITION_CONTROL, targetPosition=0, force=5, maxVelocity=2)

    p.setGravity(0, 0, -9.8)

    #update the simulation at 100 Hz
    p.setTimeStep(0.01)
    p.setRealTimeSimulation(1)
    return World(plate=plate, sphere=sphere)


if __name__ == "__main__":
    cmd_args = parse_args()
    world = run_simulation()
    run_controller(**vars(cmd_args), world=world)
    time.sleep(10000)
